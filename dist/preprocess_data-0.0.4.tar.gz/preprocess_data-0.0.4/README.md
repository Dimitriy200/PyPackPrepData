<h2>Дом проекта</h2>
<a href = "https://test.pypi.org/project/preprocess-data/0.0.3/">PyPi</a>

<h2>Установка</h2>
<code> pip install -i https://test.pypi.org/simple/ preprocess-data==0.0.3 </code>